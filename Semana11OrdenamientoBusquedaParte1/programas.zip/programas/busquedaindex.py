lista = [3, 6, 2, 8, 1, 9, 5]
elemento_a_buscar = 8
if(elemento_a_buscar in lista):
    indice = lista.index(elemento_a_buscar)
    print(indice)