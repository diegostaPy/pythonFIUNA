from mismodulos import aritmetica
from mismodulos import geometria

import funciones
funciones.saludar("diego")

print(aritmetica.sumar(7, 5))
print(geometria.mult(7, 5))