def saludar(nombre):    
     print("¡Hola,", nombre, "!")
