import random
n=random.randint(1,54)
print(n)
