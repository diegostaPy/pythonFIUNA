import math
math.log10
x=0
def sumar():
    global x
    x=x+1 
sumar()
print(x)
sumar()
print(x)